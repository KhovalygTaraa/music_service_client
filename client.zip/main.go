package main

import "music_service_client/cmd"

func main() {
	cmd.Execute()
}
